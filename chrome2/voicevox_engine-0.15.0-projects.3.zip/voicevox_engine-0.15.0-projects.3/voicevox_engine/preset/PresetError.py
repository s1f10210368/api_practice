class PresetError(Exception):
    pass
