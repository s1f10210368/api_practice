dummy2 policy

https://voicevox.hiroshiba.jp/
